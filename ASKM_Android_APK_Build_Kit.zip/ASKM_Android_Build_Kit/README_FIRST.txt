ASKM PRODUCTS — ANDROID APK BUILD KIT

IMPORTANT
This is a build kit, NOT a ready-made APK. This environment cannot compile/sign an Android APK because Android SDK/Gradle signing tools are not configured here. I do not want to pretend an APK exists when it does not.

WHAT IS INCLUDED
- ASKM Products web app
- Product catalogue, search, category filters
- Shopping cart
- WhatsApp order enquiry
- PWA files and app icons
- Capacitor configuration to wrap the app for Android

EASIEST WAY TO GET AN APK
Option 1 (recommended): use a computer with Android Studio
1. Install Node.js LTS and Android Studio.
2. Extract this ZIP.
3. Open a terminal in this folder.
4. Run: npm install
5. Run: npx cap add android
6. Run: npx cap sync android
7. Run: npx cap open android
8. In Android Studio, let Gradle sync.
9. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
10. For a shareable release, create a signed APK from Build > Generate Signed Bundle / APK.
The APK is usually under android/app/build/outputs/apk/.

Option 2: use a trusted cloud Android build service that supports Capacitor projects.
Upload the source ZIP, configure Android build, and download the generated APK. Review service pricing and permissions before uploading business assets.

FREE ALTERNATIVE WHILE YOU DON'T HAVE A BUILD ENVIRONMENT
Deploy the contents of www/ to Netlify, then open the HTTPS site in Chrome and choose Install app / Add to Home screen. This is an installable web app but it is not an APK file.

BEFORE DISTRIBUTION
- Test on real Android devices.
- Verify all products, prices, pack sizes and photos.
- The food products are currently generic placeholders at 500 g ₹79 and 1 kg ₹150; replace with exact product names.
- Prices marked "Price on enquiry" should be confirmed.
- WhatsApp order messages open to +91 93373 35730 and customers must press Send.
- No payment gateway is integrated.
- Configure privacy policy and permissions before Play Store release.
