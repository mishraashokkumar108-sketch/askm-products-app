ASKM PRODUCTS — PREMIUM ANDROID APP BUILD KIT

This kit contains the refreshed premium green-and-gold ASKM shopping app, including the ASKM Tasty food images supplied in chat.

Features:
- Premium green, cream and gold design
- Household care and ASKM Tasty food products
- Search and category filters
- Cart with quantity controls
- WhatsApp order enquiry (no online payment gateway yet)
- Food pack prices: 500 g ₹79 and 1 kg ₹150

IMPORTANT: This is app source/build material, not a compiled APK file yet. A cloud or computer Android build step is still required to produce the APK.

Main website files are in the www folder. Capacitor settings are in capacitor.config.json and package.json.

APP ICON UPDATE: The assets/icon-only.png file contains the new green-and-gold ASKM launcher icon. The GitHub Actions workflow must run `npx capacitor-assets generate --android` after `npx cap add android` and before the Gradle build.
